/*******************************************************************************
* Copyright 2017-2020 Intel Corporation.
*
* This software and the related documents are Intel copyrighted  materials,  and
* your use of  them is  governed by the  express license  under which  they were
* provided to you (License).  Unless the License provides otherwise, you may not
* use, modify, copy, publish, distribute,  disclose or transmit this software or
* the related documents without Intel's prior written permission.
*
* This software and the related documents  are provided as  is,  with no express
* or implied  warranties,  other  than those  that are  expressly stated  in the
* License.
*
* License:
* http://software.intel.com/en-us/articles/intel-sample-source-code-license-agr
* eement/
*******************************************************************************/

#ifndef _IPP_VERSION
#define _IPP_VERSION ""
#endif

#define GET_LIB_NAME01(pref) pref ## GetLibVersion

#define GET_LIB_NAME(pref) GET_LIB_NAME01(pref)

#define LIBVERNAME   s_libVer

#define SLIBVERNAME LIBVERNAME
#include "ippverstr.cxx"


IPPFUN( const IppLibraryVersion*, GET_LIB_NAME(LIB_PREFIX), (void) )
{
     return &LIBVERNAME;
}