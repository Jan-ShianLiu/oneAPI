/*******************************************************************************
* Copyright 2017-2020 Intel Corporation.
*
* This software and the related documents are Intel copyrighted  materials,  and
* your use of  them is  governed by the  express license  under which  they were
* provided to you (License).  Unless the License provides otherwise, you may not
* use, modify, copy, publish, distribute,  disclose or transmit this software or
* the related documents without Intel's prior written permission.
*
* This software and the related documents  are provided as  is,  with no express
* or implied  warranties,  other  than those  that are  expressly stated  in the
* License.
*******************************************************************************/


#ifndef __PCCNAME_H__
#define __PCCNAME_H__

/*
   The prefix of library without the quotes. The prefix is directly used to generate the
   GetLibVersion function. It is used to generate the names in the dispatcher code, in
   the version description and in the resource file.
*/
#define LIB_PREFIX          ippcc_tl

/*
   Names of library. It is used in the resource file and is used to generate the names
   in the dispatcher code.
*/
#define IPP_LIB_LONGNAME()     "Color Conversion Threading Layer"
#define IPP_LIB_SHORTNAME()    "ippCC TL"


#define GET_STR2(x)      #x
#define GET_STR(x)       GET_STR2(x)
#define IPP_LIB_PREFIX() GET_STR(LIB_PREFIX)

#define IPP_INC_NAME()   "ippcc.h"

#endif /* __PCCNAME_H__ */

/* ////////////////////////////// End of file /////////////////////////////// */
