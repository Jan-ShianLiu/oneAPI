/*******************************************************************************
* Copyright 2018-2020 Intel Corporation.
*
* This software and the related documents are Intel copyrighted  materials,  and
* your use of  them is  governed by the  express license  under which  they were
* provided to you (License).  Unless the License provides otherwise, you may not
* use, modify, copy, publish, distribute,  disclose or transmit this software or
* the related documents without Intel's prior written permission.
*
* This software and the related documents  are provided as  is,  with no express
* or implied  warranties,  other  than those  that are  expressly stated  in the
* License.
*
* License:
* http://software.intel.com/en-us/articles/intel-sample-source-code-license-agr
* eement/
*******************************************************************************/

#ifndef PIRGBTOLAB_TL_H__
#define PIRGBTOLAB_TL_H__

#include "ippcore.h"
#include "owndefs_tl.h"
#include "ippcore_tl.h"
#include "ipps.h"
#include "ippi.h"
#include "ippi_tl.h"
#include "ippcc_l.h"
#include "ippdefs.h"
#include "ownisplit_tl.h"
#include "owni_tl.h"


#ifdef USE_OMP
#include <omp.h>
#endif

#ifdef USE_OMP
/* minimal number of addition operations for threading */
#define IPP64_MIN_RGBLAB_2D        128*128
#elif defined(USE_TBB)
/* minimal number of addition operations for threading */
#define IPP64_MIN_RGBLAB_2D        128*128
#else
/* threading is not applied */
#define IPP64_MIN_RGBLAB_2D        IPP_MAX_32S
#endif


typedef struct _ippiRGBLab_32f_LT_Str
{
    Ipp32f* pSrc[3]; // const
    IppSizeL srcStep[3];
    Ipp32f* pDst[3];
    IppSizeL dstStep[3];
    IppiSizeL roiSize;
    IppiPointL splitImage;
    IppiSizeL  tileSize;
    IppiSizeL tailSize;
} ippiRGBLab_32f_LT_Str;
typedef struct _ippiRGBLab_64f_LT_Str
{
    Ipp64f* pSrc[3]; // const
    IppSizeL srcStep[3];
    Ipp64f* pDst[3];
    IppSizeL dstStep[3];
    IppiSizeL roiSize;
    IppiPointL splitImage;
    IppiSizeL  tileSize;
    IppiSizeL tailSize;
} ippiRGBLab_64f_LT_Str;

static void RGBLabThreadingStructureEncode_32f_LT (
    const Ipp32f* pSrc[3],
    IppSizeL srcStep[3],
    Ipp32f* pDst[3],
    IppSizeL dstStep[3],
    IppiSizeL roiSize,
    IppiPointL splitImage,
    IppiSizeL  tileSize,
    IppiSizeL tailSize,
    ippiRGBLab_32f_LT_Str * ts
)
{
    ts->pSrc[0] = (Ipp32f*)pSrc[0];
    ts->pSrc[1] = (Ipp32f*)pSrc[1];
    ts->pSrc[2] = (Ipp32f*)pSrc[2];
    ts->srcStep[0] = srcStep[0];
    ts->srcStep[1] = srcStep[1];
    ts->srcStep[2] = srcStep[2];
    ts->pDst[0] = pDst[0];
    ts->pDst[1] = pDst[1];
    ts->pDst[2] = pDst[2];
    ts->dstStep[0] = dstStep[0];
    ts->dstStep[1] = dstStep[1];
    ts->dstStep[2] = dstStep[2];
    ts->roiSize = roiSize;
    ts->splitImage = splitImage;
    ts->tileSize = tileSize;
    ts->tailSize = tailSize;
}
static void RGBLabThreadingStructureEncode_64f_LT(
    const Ipp64f* pSrc[3],
    IppSizeL srcStep[3],
    Ipp64f* pDst[3],
    IppSizeL dstStep[3],
    IppiSizeL roiSize,
    IppiPointL splitImage,
    IppiSizeL  tileSize,
    IppiSizeL tailSize,
    ippiRGBLab_64f_LT_Str * ts
)
{
    ts->pSrc[0] = (Ipp64f*)pSrc[0];
    ts->pSrc[1] = (Ipp64f*)pSrc[1];
    ts->pSrc[2] = (Ipp64f*)pSrc[2];
    ts->srcStep[0] = srcStep[0];
    ts->srcStep[1] = srcStep[1];
    ts->srcStep[2] = srcStep[2];
    ts->pDst[0] = pDst[0];
    ts->pDst[1] = pDst[1];
    ts->pDst[2] = pDst[2];
    ts->dstStep[0] = dstStep[0];
    ts->dstStep[1] = dstStep[1];
    ts->dstStep[2] = dstStep[2];
    ts->roiSize = roiSize;
    ts->splitImage = splitImage;
    ts->tileSize = tileSize;
    ts->tailSize = tailSize;
}
#endif // PIRGBTOLAB_TL_H__
