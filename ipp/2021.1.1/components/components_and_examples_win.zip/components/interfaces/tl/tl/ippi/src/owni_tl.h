/*******************************************************************************
* Copyright 2015-2020 Intel Corporation.
*
* This software and the related documents are Intel copyrighted  materials,  and
* your use of  them is  governed by the  express license  under which  they were
* provided to you (License).  Unless the License provides otherwise, you may not
* use, modify, copy, publish, distribute,  disclose or transmit this software or
* the related documents without Intel's prior written permission.
*
* This software and the related documents  are provided as  is,  with no express
* or implied  warranties,  other  than those  that are  expressly stated  in the
* License.
*******************************************************************************/

#ifndef __OWNIL_H__
#define __OWNIL_H__

#ifndef __OWNDEFSL_H__
  #include "owndefs_tl.h"
#endif

#include "ippcore_tl.h"

#ifndef __IPPIL_H__
  #include "ippi_tl.h"
#endif
#ifdef __cplusplus
extern "C" {
#endif
extern Ipp8u* owniGetImagePointer_8u_C1(const Ipp8u* pData, IppSizeL dataStep, IppSizeL col, IppSizeL row);
extern Ipp8u* owniGetImagePointer_8u_C3(const Ipp8u* pData, IppSizeL dataStep, IppSizeL col, IppSizeL row);
extern Ipp8u* owniGetImagePointer_8u_C4(const Ipp8u* pData, IppSizeL dataStep, IppSizeL col, IppSizeL row);
extern Ipp8u* owniGetImagePointer_8u_AC4(const Ipp8u* pData, IppSizeL dataStep, IppSizeL col, IppSizeL row);

extern Ipp16u* owniGetImagePointer_16u_C1(const Ipp16u* pData, IppSizeL dataStep, IppSizeL col, IppSizeL row);
extern Ipp16u* owniGetImagePointer_16u_C3(const Ipp16u* pData, IppSizeL dataStep, IppSizeL col, IppSizeL row);
extern Ipp16u* owniGetImagePointer_16u_C4(const Ipp16u* pData, IppSizeL dataStep, IppSizeL col, IppSizeL row);
extern Ipp16u* owniGetImagePointer_16u_AC4(const Ipp16u* pData, IppSizeL dataStep, IppSizeL col, IppSizeL row);

extern Ipp16s* owniGetImagePointer_16s_C1(const Ipp16s* pData, IppSizeL dataStep, IppSizeL col, IppSizeL row);
extern Ipp16s* owniGetImagePointer_16s_C3(const Ipp16s* pData, IppSizeL dataStep, IppSizeL col, IppSizeL row);
extern Ipp16s* owniGetImagePointer_16s_C4(const Ipp16s* pData, IppSizeL dataStep, IppSizeL col, IppSizeL row);
extern Ipp16s* owniGetImagePointer_16s_AC4(const Ipp16s* pData, IppSizeL dataStep, IppSizeL col, IppSizeL row);

extern Ipp64f* owniGetImagePointer_64f(const Ipp64f* pData, IppSizeL dataStep, IppSizeL w, IppSizeL h, Ipp32s nCh);
extern Ipp32f* owniGetImagePointer_32f(const Ipp32f* pData, IppSizeL dataStep, IppSizeL w, IppSizeL h, Ipp32s nCh);
extern Ipp16s* owniGetImagePointer_16s(const Ipp16s* pData, IppSizeL dataStep, IppSizeL w, IppSizeL h, Ipp32s nCh);
extern Ipp16u* owniGetImagePointer_16u(const Ipp16u* pData, IppSizeL dataStep, IppSizeL w, IppSizeL h, Ipp32s nCh);
extern Ipp8u* owniGetImagePointer_8u(const Ipp8u* pData, IppSizeL dataStep, IppSizeL w, IppSizeL h, Ipp32s nCh);

extern Ipp32s* owniGetImagePointer_32s_C1(const Ipp32s* pData, IppSizeL dataStep, IppSizeL col, IppSizeL row);
#ifdef __cplusplus
}
#endif

#endif /* IPP64_OWNS */
