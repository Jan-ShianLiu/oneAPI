/*******************************************************************************
* Copyright 2018-2020 Intel Corporation.
*
* This software and the related documents are Intel copyrighted  materials,  and
* your use of  them is  governed by the  express license  under which  they were
* provided to you (License).  Unless the License provides otherwise, you may not
* use, modify, copy, publish, distribute,  disclose or transmit this software or
* the related documents without Intel's prior written permission.
*
* This software and the related documents  are provided as  is,  with no express
* or implied  warranties,  other  than those  that are  expressly stated  in the
* License.
*
* License:
* http://software.intel.com/en-us/articles/intel-sample-source-code-license-agr
* eement/
*******************************************************************************/

#ifndef PIFILBILBRD_TL_H__
#define PIFILBILBRD_TL_H__

#include "ippcore.h"
#include "owndefs_tl.h"
#include "ippcore_tl.h"
#include "ipps.h"
#include "ippi.h"
#include "ippdefs.h"
#include "ownisplit_tl.h"
#include "owni_tl.h"



#ifdef USE_OMP
#include <omp.h>
#endif

#define D_ALIGN 32
#define ippBorderInMemAll   ((int)(ippBorderInMemTop|ippBorderInMemBottom|ippBorderInMemLeft|ippBorderInMemRight))

typedef struct
{
    IppiPointL  split;
    IppiSizeL   tileSize;
    IppiSizeL   lastTile;
    IppDataType dataType;
    Ipp32u      numChannels;
    IppSizeL   bufsize;
    IppSizeL      radius;
} BilateralInfo;

#define TYLE_S (maskSize.height + 1)

typedef struct _ippiFilterBilateral_LT_Str
{
    Ipp8u * pSrc; //const
    IppSizeL srcStep; 
    Ipp8u * pDst; 
    IppSizeL dstStep;  
    IppiBorderType border; 
    Ipp8u * borderValue; 
    IppiFilterBilateralSpec_LT * pSpec; //const
    Ipp8u * pBuffer;
    IppSizeL bufSize;
    IppSizeL numChannels;
    IppiPointL splitImage;
    IppiSizeL pTileSize; 
    IppiSizeL pLastSize;
} ippiFilterBilateral_LT_Str;
typedef struct _ippiFilterBilateral_P3_LT_Str
{
    Ipp8u * pSrc[3]; //const
    IppSizeL srcStep[3];
    Ipp8u * pDst[3];
    IppSizeL dstStep[3];
    IppiBorderType border;
    Ipp8u * borderValue;
    IppiFilterBilateralSpec_LT * pSpec; //const
    Ipp8u * pBuffer;
    IppSizeL bufSize;
    IppSizeL numChannels;
    IppiPointL splitImage;
    IppiSizeL pTileSize;
    IppiSizeL pLastSize;
} ippiFilterBilateral_P3_LT_Str;

static void fBilateralBrdThreadingStructureEncode (
    Ipp8u * pSrc,
    IppSizeL srcStep, 
    Ipp8u * pDst, 
    IppSizeL dstStep, 
    IppiBorderType border, 
    Ipp8u * borderValue, 
    IppiFilterBilateralSpec_LT * pSpec,
    Ipp8u * pBuffer,
    IppSizeL bufSize,
    IppSizeL numChannels,
    IppiPointL splitImage,
    IppiSizeL pTileSize, 
    IppiSizeL pLastSize,   
    ippiFilterBilateral_LT_Str * ts
)
{
    ts->pSrc = pSrc;
    ts->srcStep = srcStep;
    ts->pDst = pDst;
    ts->dstStep = dstStep;
    ts->border = border;
    ts->borderValue = borderValue;
    ts->pSpec = pSpec;
    ts->pBuffer = pBuffer;
    ts->bufSize = bufSize;
    ts->numChannels = numChannels;
    ts->splitImage = splitImage;
    ts->pTileSize = pTileSize;
    ts->pLastSize = pLastSize;
}
static void fBilateralBrdThreadingStructureEncode_P3(
    Ipp8u * pSrc[3],
    IppSizeL srcStep[3],
    Ipp8u * pDst[3],
    IppSizeL dstStep[3],
    IppiBorderType border,
    Ipp8u * borderValue,
    IppiFilterBilateralSpec_LT * pSpec,
    Ipp8u * pBuffer,
    IppSizeL bufSize,
    IppSizeL numChannels,
    IppiPointL splitImage,
    IppiSizeL pTileSize,
    IppiSizeL pLastSize,
    ippiFilterBilateral_P3_LT_Str * ts
)
{
    int n;
    for (n = 0; n < 3; n++) {
        ts->pSrc[n] = pSrc[n];
        ts->srcStep[n] = srcStep[n];
        ts->pDst[n] = pDst[n];
        ts->dstStep[n] = dstStep[n];
    }
    ts->border = border;
    ts->borderValue = borderValue;
    ts->pSpec = pSpec;
    ts->pBuffer = pBuffer;
    ts->bufSize = bufSize;
    ts->numChannels = numChannels;
    ts->splitImage = splitImage;
    ts->pTileSize = pTileSize;
    ts->pLastSize = pLastSize;
}
#endif // PIFILBILBRD_TL_H__
